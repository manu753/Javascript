(function(){
    
    function getUser(){
        return new Promise(function(resolve,reject){
            var url="https://api.github.com/users";
           var connection=new XMLHttpRequest();
            connection.open("get",url,true);
            connection.send();
            connection.onreadystatechange=function(){
                if(this.status==200 && this.readyState==4){
                    var parseuser=JSON.parse(connection.response);
                    console.log(parseuser);
                    resolve(parseuser);
                }
                else 
                    if(this.status==402 && this.status==404){
                        reject("error in fetching");
                    }
            }
        });
    }
    
    function fetchuserdetail(obj){
       var users=obj;
        for(var i=0;i<users.length;i++){
            
         var card=document.createElement('div');
        card.className='card';
        var profile_img=document.createElement('div');
        profile_img.className='user_img';
        var user_img=document.createElement('img');
        user_img.src=users[i].avatar_url;
        var user_info=document.createElement('div');
        user_info.className='user_info';
        var profilename=document.createElement('div');
        profilename.className="profile_name";
        profilename.textContent=users[i].login;
        var userdetail=document.createElement('ul');
        userdetail.className="user_detail";
        var location=document.createElement('li');
        location.className="location";
        var email=document.createElement('li');
        email.className="email";
        var blog=document.createElement('li');
        blog.className="blog";
        var location_img=document.createElement('img');
        location_img.src="img/location.svg";
        var location_detail=document.createElement('span');
        location_detail.textContent="San Francisco";
        var email_img=document.createElement('img');
        email_img.src="img/mail.svg";
        var email_detail=document.createElement('span');
        var email_links=document.createElement("a");
        email_links.href="#";
        email_links.textContent="tom@mojombo.com";
        var blog_img=document.createElement('img');
        blog_img.src="img/blog.svg";
        var blog_detail=document.createElement('span');
        var blog_links=document.createElement("a");
        blog_links.href="#";
        blog_links.textContent=users[i].url;
        //var p=document.querySelector(""); 
        var mainbody = document.getElementById("mainbody");
       // var getcard=document.querySelector('.card');
        //var getpofile_img=document.querySelector('.user_img');
        profile_img.appendChild(user_img);
        card.appendChild(profile_img);
        mainbody.appendChild(card);
        card.appendChild(user_info);
        user_info.appendChild(profilename);
        user_info.appendChild(userdetail);
        userdetail.appendChild(location);
        location.appendChild(location_img);
        location.appendChild(location_detail);
        
        userdetail.appendChild(email);
        email.appendChild(email_img);
        email.appendChild(email_detail);
        email_detail.appendChild(email_links);
        userdetail.appendChild(blog);
        blog.appendChild(blog_img);
        blog.appendChild(blog_detail);
        blog_detail.appendChild(blog_links);
       }
    }
                           
    getUser().then(function(response){
        return fetchuserdetail(response);
        
    }).catch(function(error){
        console.log(error);
    });
        
})();
