'use strict';

// Register `phoneList` component, along with its associated controller and template
angular.
  module('phoneList').
  component('phoneList', {
    templateUrl: 'phone-list/phone-list.template.html',
    controller: ['$http','$log',function PhoneListController($http , $log) {
      var self=this;
	  $http.get('phones/phones.json').then(function(response){
	  		self.phones=response.data;
		  $log.info(self.phones);
	  });
	  
      this.orderProp = 'age';
    }],
	
	
  });
