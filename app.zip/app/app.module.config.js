angular.module('phonecatApp')
.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider){
	$routeProvider
		.when('/phone',{
			template:'<phone-list></phone-list>'
		})
		.when('/phone/:phoneId',{
			template:'<phone-detail></phone-detail>'
		})
		.otherwise('phone');
	   
		
}]);