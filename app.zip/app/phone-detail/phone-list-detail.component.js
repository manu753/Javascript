angular.module('phoneDetail')
.component('phoneDetail',{
	
		template:'hi this is phone detail view'
		/*controller:['$routeParams',function phoneDetail($routeParams){
						
		}]*/
			

});